# women-power

Womenpower is a web application blog that allow user to create,delete and like posts. The user must first be registered and logged in to use all these features.
Users can create their own account with their profile picture, And they can always update their user name, image and password. 

# Objective 

The goal of this website application is for women to comminicate, inspire and encourage eachother by sharing their ideas, opinions and experiences.


# technologies

- HTML5
- CSS
- Bootstrap
- Flask
- SQLite

This website application is working perfectly fine in my local host,  but  because I used Sqlite database I find it difficult to deploy it on Heroku.

# Website requirements
- Home page
- About Us page
- Register Page
- Loggin Page
- Create Blog page
- Account update page
- like and delete buttons


# User Scenario
If the user is his first time  using this web application,  the user must register first  and it will redirect the user to the login page then after the user logged in it will redirect the user to the home page. In the home page you can see posts, like post and delete your own post.  If the user want to create blog, the user can  go to createblog page  and  create a post in there. If a user go to the account update page  the user can update his user name, profile picture and update their Password, the user must update his password with a new password but  if the user tried to update his new password with the same password as before, it will not let the user to change the password.

All the latest posts the user can see it in the small box, where there is a profile picture  on the top of it, if the user is logged in.currently.

If you the user is returning to the website again if they are already logged in they dont need to login again. But if they are logged out they can login and use the web application again.

